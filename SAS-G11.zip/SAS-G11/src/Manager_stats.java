import com.toedter.calendar.JDateChooser;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.jdbc.JDBCCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Manager_stats extends JFrame {
    private JTextField textField1;
    private JPanel startDate;
    private JPanel endDate;
    public JPanel main_stats_panel;
    private JPanel sub_panel;
    private JComboBox cb;
    private JPanel cbp;
    private JButton button1;
    private JScrollPane scrollpane;
    JFrame f;
    JDateChooser dc1, dc2;

    public void set_date_and_cb() throws ParseException {
        dc1 = new JDateChooser();
        startDate.add(dc1);

        dc2 = new JDateChooser();
        endDate.add(dc2);

        String d1 = 2022 + "-" + 01 + "-" + 05;
        Date date = new SimpleDateFormat("yyyy-MM-dd").parse(d1);
        dc1.setDate(date);

        String d2 = 2022 + "-" + 03 + "-" + 23;
        Date date2 = new SimpleDateFormat("yyyy-MM-dd").parse(d2);
        dc2.setDate(date2);


        String ITEMS[] = {"Line Graph-Quantity Sales", "Line Graph-Profits"};
        cb = new JComboBox<>(ITEMS);
        cbp.add(cb);


    }

    public void create_chart(Connection con, String qr, int mode) throws SQLException {
        String q = qr;
        PreparedStatement ps = con.prepareStatement(q);
        ResultSet result = ps.executeQuery();
        if (!result.next()) {
            JOptionPane.showMessageDialog(null, "No data to show");
            return;
        }

        JDBCCategoryDataset dataset = new JDBCCategoryDataset(con, q);
        String ylabel;
        if (mode == 0) {
            ylabel = "Quantity";
        }else{
            ylabel= "PROFIT";
        }
        JFreeChart chart = ChartFactory.createLineChart("SALES STATISTICS", "DATE", ylabel, dataset, PlotOrientation.VERTICAL, false, true, true);
        CategoryPlot plot = chart.getCategoryPlot();
        ;

        LineAndShapeRenderer renderer = new LineAndShapeRenderer();
        plot.setRenderer(renderer);

        assert plot != null;
        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlinePaint(Color.BLACK);

        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePaint(Color.BLACK);
        sub_panel.setLayout(new java.awt.BorderLayout());
        ChartPanel CP = new ChartPanel(chart);
        sub_panel.add(CP, BorderLayout.CENTER);
        sub_panel.validate();
        CategoryAxis axis = chart.getCategoryPlot().getDomainAxis();
        axis.setCategoryLabelPositions(CategoryLabelPositions.UP_90);
    }

    Manager_stats() throws ParseException {
        set_date_and_cb();
        cb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == cb) {
                    System.out.println(cb.getSelectedIndex());
                    Connection con = initialise_db.getConnection();
                    assert con != null;
                    PreparedStatement s1 = null;
                    try {
                        if(textField1.getText()==null||textField1.getText().equals("")){
                            JOptionPane.showMessageDialog(null,"Input field can't be null");
                        }
                        s1 = con.prepareStatement("USE SAS");
                        s1.executeUpdate();
                        SimpleDateFormat dcn = new SimpleDateFormat("yyyy-MM-dd");
                        String startdate = dcn.format(dc1.getDate());

                        SimpleDateFormat dcn1 = new SimpleDateFormat("yyyy-MM-dd");
                        String enddate = dcn1.format(dc2.getDate());

                        String Where = "WHERE item_id ='"+textField1.getText()+"'";
                        if (cb.getSelectedIndex() == 0) {
                            sub_panel.removeAll();
                            String q = "select date,SUM(quantity) from sales_record "+Where+"group by date";
                            create_chart(con, q, 0);

                        } else {
                            sub_panel.removeAll();
                            String q = "select DATE ,SUM((profit*quantity)-(quantity*unitprice)) as DIFF from sales_record " +
                                    "WHERE DATE BETWEEN '" + startdate + "' AND '" + enddate + "' AND item_id ='"+textField1.getText()+"' GROUP BY DATE " + "ORDER BY DATE";
                            System.out.println(q);
                            System.out.println(q);
                            create_chart(con, q, 1);

                        }
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, ex.getMessage());
                    }

                }
            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Manager_main.f.dispose();
            }
        });
    }
}
