
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class initialise_db {
    public static Connection getConnection() {
        try {
            String driver = "com.mysql.cj.jdbc.Driver";
            String url = "jdbc:mysql://localhost/";
            String username = "root";
            String password = "bantu";
            Class.forName(driver);

            Connection conn = DriverManager.getConnection(url, username, password);
            System.out.println("Connected");
            return conn;
        } catch (Exception e) {
            System.out.println("TYOYOYOYOY");
            System.out.println(e);
        }
        return null;
    }

    public static void create_database() {
        try {
            Connection con = getConnection();
            assert con != null;
            PreparedStatement q = con.prepareStatement("DROP database IF EXISTS SAS");
            q.executeUpdate();

            PreparedStatement create = con.prepareStatement("CREATE DATABASE IF NOT EXISTS SAS");
            create.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public static void fill_data(String file, Connection conn, String querry) {
        String line = "";
        String splitBy = ",";
        String oldquerry = querry;
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            while ((line = br.readLine()) != null) {
                String[] employee = line.split(splitBy);
                querry = oldquerry;
                querry += "(";
                for (int i = 0; i < employee.length; i++) { // handle case when two emp ids are same;
                    querry += "\"" + employee[i] + "\"";
                    if (i != (employee.length - 1))
                        querry += ",";
                }
                querry += ")";
                System.out.println(querry);

                PreparedStatement ps_1 = conn.prepareStatement(querry);
                ps_1.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static void create_employee_table(Connection con) {
        PreparedStatement create;
        try {
            create = con.prepareStatement(
                    "CREATE TABLE IF NOT EXISTS Employee (emp_type VARCHAR(50),name VARCHAR(30),emp_id VARCHAR(10),email VARCHAR(30),mobile VARCHAR(30),sales_clerk VARCHAR(15), password VARCHAR(50))");
            create.executeUpdate();
            fill_data("src/files/input.csv", con,
                    "INSERT INTO Employee(emp_type,name,emp_id,email,mobile,password) VALUES "); // hash
            // password

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void create_sales_record(Connection con) {
        String line = "";
        try {
            String s = "create table if not exists sales_record (date DATE,t_id INT,item_id INT,Quantity INT,UnitPrice INT,Discount INT,GST INT,PROFIT INT)";
            PreparedStatement ps = con.prepareStatement(s);
            ps.executeUpdate();
            BufferedReader br = new BufferedReader(new FileReader("src/files/sales_record.txt"));
            while ((line = br.readLine()) != null) {
                String querry = line;
                PreparedStatement ps_1 = con.prepareStatement(querry);
                ps_1.executeUpdate();
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static void create_item_table(Connection con) {
        PreparedStatement create;
        try {
            create = con.prepareStatement(
                    "CREATE TABLE IF NOT EXISTS Item (name VARCHAR(30) NOT NULL,item_id VARCHAR(20) NOT NULL,manufacturer VARCHAR(30)  NOT NULL,MRP DOUBLE  NOT NULL,cost DOUBLE  NOT NULL,discount DOUBLE  NOT NULL,quantity DOUBLE  NOT NULL,PRIMARY KEY (item_id))");
            create.executeUpdate();
            fill_data("C:\\Users\\Dell\\Desktop\\rr\\src\\item.csv", con,
                    "INSERT INTO Item(name,item_id,manufacturer,MRP,cost,discount,quantity) VALUES "); // hash
            // password

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void create_table() {
        try {
            Connection con = getConnection();
            assert con != null;
            PreparedStatement s1 = con.prepareStatement("USE SAS");
            s1.executeUpdate();
            create_employee_table(con);
            create_item_table(con);
            create_sales_record(con);

        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("I'm done");
    }
}
