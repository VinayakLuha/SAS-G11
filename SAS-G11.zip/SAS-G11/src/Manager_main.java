import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;

public class Manager_main extends JFrame{
    private JPanel main_panel;
    private JButton stats_btn;
    private JButton im_btn;
    private JPanel display_panel;
    private JLabel ltoc;
    public static JFrame f;

    Manager_main(int mode) throws SQLException, ParseException {

        f= new JFrame();
        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
        f.setContentPane(this.main_panel);
        f.setVisible(true);
        ImageIcon image = new ImageIcon("src\\images\\SAS.png");
        f.setIconImage(image.getImage());

        Manager_stats ms= new Manager_stats();
        display_panel.add(ms.main_stats_panel,"1");
        display_panel.setVisible(false);
        Manager_inventory MI = new Manager_inventory();

        if(mode==0){
            f.setTitle("SAS-Homepage>>Manager's_login_page>>InventoryManagement/SalesStatistics");
        }
        else{
            f.setTitle("SAS-Homepage>>Employee's_login_page>>InventoryManagement");
            stats_btn.setEnabled(false);
            MI.update.setEnabled(false);
            MI.showButton.setEnabled(false);
            ltoc.setText("Employee's screen");
        }

        display_panel.add(MI.main_inv_panel,"2");
        display_panel.setVisible(false);

        stats_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cardLayout = (CardLayout) display_panel.getLayout();
                cardLayout.show(display_panel, "1");
                display_panel.setVisible(true);
            }
        });
        im_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cardLayout = (CardLayout) display_panel.getLayout();
                cardLayout.show(display_panel, "2");
                display_panel.setVisible(true);
            }
        });
    }
}
