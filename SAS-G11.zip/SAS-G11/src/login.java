import org.jfree.chart.JFreeChart;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class login extends JFrame {
    private JTextField tf;
    private JPasswordField pf;
    private JButton login_btn;
    public JPanel Main_login_panel;
    private JLabel greet;
    public JButton back_btn;
    private JLabel un;
    private JLabel pw;
    public static billing b;
    public static JFrame jf;
    String id;
    String pass;

    public void set_random_id_pass() {
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("baburam789", "987marubab");
        map.put("sneha456", "654ahens");
        map.put("preeti123", "321iteerp");
        map.put("aaditya123", "321aytidaa");
        map.put("vinayak456", "654kayaniv");

        List<String> keylist = new ArrayList<String>(map.keySet());
        int randomIndex = new Random().nextInt(keylist.size());
        id = keylist.get(randomIndex);
        pass = map.get(id);

        tf.setText(id);
        pf.setText(pass);

    }

    login(String str, int role) {
        un.setForeground(Color.white);
        pw.setForeground(Color.white);
        set_random_id_pass();
        ImageIcon image = new ImageIcon("src\\images\\SAS.png");
        this.setIconImage(image.getImage());
        if(id=="sneha456"||id=="preeti123"){
            str = str.substring(0, 4) + 's'
                    + str.substring(4 + 1);
            greet.setText(String.valueOf(str));
        }else
            greet.setText(str);
        back_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Homepage.hp.setVisible(true);
                Homepage.lg.dispose();
            }
        });
        login_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tf.getText().equals("") || pf.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Username or password field can't be empty");
                    return;
                }

                try {
                    initialise_db idb = new initialise_db();
                    Connection con = idb.getConnection();
                    assert con != null;
                    PreparedStatement s1 = con.prepareStatement("USE SAS");
                    s1.executeUpdate();

                    String extra = "";
                    extra += "and emp_type=";
                    if (role == 0) {
                        extra += "'sales_clerk'";
                    } else if (role == 1) {
                        extra += "'manager'";
                    } else {
                        extra += "'employee'";
                    }


                    PreparedStatement q = con.prepareStatement("SELECT * from employee" +
                            " where emp_id =" + "'" + tf.getText() + "'" + "and password=" + "'" + pf.getText() + "'" + extra);
                    System.out.println(q);
                    ResultSet result = q.executeQuery();


                    if (!result.next()) {
                        JOptionPane.showMessageDialog(null, "Username and password field mismatch");
                    } else {
                        if (role == 0) {
                            System.out.println("verified sales_clerk");
                            jf = new JFrame();
                            b = new billing();
                            jf.setTitle("SAS-Homepage>>Sales_Clerk_login>>Billing");
                            jf.setContentPane(b.billing_panel);
                            jf.setExtendedState(JFrame.MAXIMIZED_BOTH);
                            jf.setVisible(true);
                        } else if (role == 1) {
                            System.out.println("verified manager");
                            JFrame f = new Manager_main(0);
                            f.setTitle("SAS-Homepage>>Manager's_login>>Statistics/Inventory_Management");
                            f.setExtendedState(JFrame.MAXIMIZED_BOTH);
                        } else {
                            JFrame f = new Manager_main(1);
                            f.setExtendedState(JFrame.MAXIMIZED_BOTH);

                        }

                    }
                } catch (Exception excp) {
                    System.out.println(excp);
                }

            }
        });
    }
}
