import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;

public class Manager_inventory extends JFrame {
    private JTextField item_id;
    public JButton update;
    private JTable table;
    public JPanel main_inv_panel;
    private JButton search;
    public JButton showButton;
    private JButton add;
    public JButton done_btn;
    int items_per_bill;
    JFrame f;


    public void set_table_content(int mode, String str) throws SQLException {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>(100);
        table.setModel(new DefaultTableModel(
                null, new String[]{"name", "item_id", "manufacturer", "MRP", "cost", "discount", "quantity"}));

        try {
            Connection con = initialise_db.getConnection();
            assert con != null;
            PreparedStatement s1 = con.prepareStatement("USE SAS");
            s1.executeUpdate();

            String sqll = "SELECT * from item";
            PreparedStatement q;
            if (mode == 1) {
                String sql = "SELECT * FROM ITEM " +
                        "WHERE item_id = '" + str + "' or name like '%" + str + "%'";
                System.out.println(sql);
                q = con.prepareStatement(sql);
            } else {
                q = con.prepareStatement(sqll);
            }
            ResultSet result = q.executeQuery();
            if (!result.next()) {
                if (mode == 1) {
                    int respone = JOptionPane.showConfirmDialog(null, "Item Unavailable ,Would you like to Add item ?");
                    switch (respone) {
                        case JOptionPane.YES_OPTION:
                            System.out.println("Yes");
                            insert_into_db(con);
                            break;
                        case JOptionPane.NO_OPTION:
                            break;
                        case JOptionPane.CANCEL_OPTION:
                            break;
                        case JOptionPane.CLOSED_OPTION:
                            break;
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Item Unavailable");
                }

            } else {

                int count = 0;
                while (true) {
                    count++;
                    ArrayList<String> arrtemp = new ArrayList<String>();
                    for (int i = 1; i <= 7; i++) {
                        arrtemp.add(result.getString(i));
                    }
                    data.add(arrtemp);
                    if (!result.next()) {
                        break;
                    }
                }
                System.out.println(count);
                items_per_bill = count;
                for (int i = 0; i < items_per_bill; i++) {
                    System.out.println(data.get(i));
                }
                String[][] strarr = new String[items_per_bill][7];
                for (int i = 0; i < items_per_bill; i++) {
                    for (int j = 0; j < 7; j++) {
                        strarr[i][j] = data.get(i).get(j);
                    }
                }
                table.setModel(new DefaultTableModel(
                        strarr,
                        new String[]{"name", "item_id", "manufacturer", "MRP", "cost", "discount", "quantity"}));
                table.setRowHeight(30);
            }


        } catch (Exception excp) {
            System.out.println(excp);

        }

    }

    public void delete_and_add(int del) throws SQLException {
        int inserts=0;
        Connection con = initialise_db.getConnection();
        assert con != null;
        PreparedStatement s1 = con.prepareStatement("USE SAS");
        s1.executeUpdate();

        int rows = table.getRowCount();
        System.out.println(rows);
        for (int row = 0; row < rows; row++) {

            String item_id = (String) table.getValueAt(row, 1);
            if (item_id==null||item_id.equals(""))
                continue;
            inserts++;
            String sql1 = "SET SQL_SAFE_UPDATES = 0;";
            String sql2 = "DELETE FROM ITEM WHERE item_id =" + "'" + item_id + "'";
            String sql3 = "Insert into item values (?,?,?,?,?,?,?)";

            try {
                double d = Double.parseDouble(item_id);
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(null, "Item_id should be numeric" + item_id);
            }

            if (del==0&&Integer.parseInt(item_id) < Integer.parseInt(item_id)) {
                JOptionPane.showMessageDialog(null, "Item id should be atleast " + item_id);
                return;
            }

            PreparedStatement pst1 = con.prepareStatement(sql1);
            PreparedStatement pst2 = con.prepareStatement(sql2);
            if (del == 1) {
                pst1.executeUpdate();
                pst2.executeUpdate();


            }
            PreparedStatement pst3 = con.prepareStatement(sql3);
            String name = (String) table.getValueAt(row, 0);
            String id = (String) table.getValueAt(row, 1);

            String manu = (String) table.getValueAt(row, 2);
            String mrp = (String) table.getValueAt(row, 3);
            String cost = (String) table.getValueAt(row, 4);
            String dis = (String) table.getValueAt(row, 5);
            String quan = (String) table.getValueAt(row, 6);

            System.out.println(name + " " + id + " " + manu + " " + mrp+" "+dis+" "+quan);

            pst3.setString(1, name);
            pst3.setString(2, id);
            pst3.setString(3, manu);
            pst3.setString(4, mrp);
            pst3.setString(5, cost);
            pst3.setString(6, dis);
            pst3.setString(7, quan);
            System.out.println(pst3);
            pst3.executeUpdate();
        }
        if(inserts==0){
            JOptionPane.showMessageDialog(null, "Empty rows to insert");
            return;
        }
        if (del == 1)
            JOptionPane.showMessageDialog(null, "Update Successful!");
        else
            JOptionPane.showMessageDialog(null, "Item added Successfully!");

    }

    private void insert_into_db(Connection con) {
        String[][] strarr = new String[5][7];
        table.setModel(new DefaultTableModel(
                strarr,
                new String[]{"name", "item_id", "manufacturer", "MRP", "cost", "discount", "quantity"}));
        table.setRowHeight(30);

    }


    Manager_inventory() throws SQLException {
        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    set_table_content(2, "");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (item_id.getText().equals(""))
                        JOptionPane.showMessageDialog(null, "Input field can't be empty");
                    else
                        set_table_content(1, item_id.getText());
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    delete_and_add(1);
                } catch (Exception ee) {
                    System.out.println(ee);
                }
            }
        });
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    delete_and_add(0);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning",
                            JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        done_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Manager_main.f.dispose();
            }
        });
    }
}
