import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

public class Homepage extends JFrame {
    private JPanel Home_panel;
    private JButton scb;
    private JButton mb;
    private JButton empb;
    private JLabel top_label;
    private  JLabel right_image_label;
    private JProgressBar progressBar1;
    private JPanel Imagepanel;
    public static Homepage hp;
    public static login lg;

    public Homepage() {
        ImageIcon ic =scale_down("src/images/cover.jpg",700,1000);
        right_image_label.setIcon(ic);
        ImageIcon image = new ImageIcon("src/images/SAS.png");
        this.setIconImage(image.getImage());
        scb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                init_login("Hi Mr SalesClerk!", 0);
                hp.setVisible(false);

            }
        });

        mb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                init_login("Hi Mr Manager!", 1);
                hp.setVisible(false);
            }
        });

        empb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                init_login("Hi Mr Employee!", 2);
                hp.setVisible(false);
            }
        });
    }

    public void init_login(String str, int i) {
        lg = new login(str, i);
        lg.setContentPane(lg.Main_login_panel);
        String stri= "SAS-Homepage>>";
        if (i == 0) {
            stri += "Sales_Clerk's_login_screen";
        } else if (i == 1) {
            stri += "Manager's_login_Screen";
        } else
            stri += "Employee's_login_Screen";
        lg.setTitle(stri);
        lg.setExtendedState(JFrame.MAXIMIZED_BOTH);
        lg.setVisible(true);
    }

    public static ImageIcon scale_down(String path, int h, int w) {
        ImageIcon imageIcon = new ImageIcon(path);
        Image image = imageIcon.getImage();
        Image newimg = image.getScaledInstance(w, h, java.awt.Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newimg);
        return imageIcon;
    }

    public static void main(String[] args) {
        initialise_db idb = new initialise_db();
        idb.create_database();
        idb.create_table();
        hp = new Homepage();
        hp.setTitle("SAS-Homepage");
        hp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        hp.setContentPane(hp.Home_panel);
        hp.setExtendedState(JFrame.MAXIMIZED_BOTH);
        hp.setVisible(true);



    }
}
