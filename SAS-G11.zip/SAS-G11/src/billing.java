import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class billing {
    private JTextField item_id;
    private JTextField discount;
    private JTextField gst;
    private JSpinner quantity;
    private JButton button1;
    private  JTable table;
    private JButton DONEButton;
    private JButton downloadBillButton;
    public JPanel billing_panel;
    private JButton add_btn;
    private JTextField net_ammo;
    private JLabel t_idnum;
    private JLabel dt;
    ArrayList<ArrayList<String>> data;
    int items_per_bill=20;
    static int t_id;

    public static void create_sales_record_table(Connection con) {
        PreparedStatement create;
        try {
            create = con.prepareStatement(
                    "CREATE TABLE IF NOT EXISTS sales_record (date DATE,t_id INTEGER,item_id INTEGER,Quantity INTEGER,UnitPrice DOUBLE,Discount DOUBLE,GST DOUBLE ,PROFIT DOUBLE)");
            create.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Here");
            e.printStackTrace();
        }
    }

        public  void ImageInFrame(String img_name) throws IOException {
            String path = img_name;
            File file = new File(path);
            BufferedImage image = ImageIO.read(file);
            JLabel label = new JLabel(new ImageIcon(image));
            JFrame f = new JFrame();
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.getContentPane().add(label);
            f.pack();
            f.setLocation(200,200);
            f.setVisible(true);
        }

        public java.sql.Date set_date_n_invoiceNO(){
            int max=100000;
            int min=000000;
            t_id= (int) (Math.random() * (max - min + 1) + min);
            t_idnum.setText("INVOICE NO."+String.valueOf(t_id));

            java.util.Date javaDate = new java.util.Date();
            java.sql.Date date = new java.sql.Date(javaDate.getTime());
            dt.setText("Date: "+String.valueOf(date));
            return date;
        }

    public static void makeScreenshot(JFrame jf) throws AWTException, IOException {
        BufferedImage img = new BufferedImage(jf.getWidth(), jf.getHeight(), BufferedImage.TYPE_INT_RGB);
        jf.paint(img.getGraphics());
        ImageIO.write(img, "png", new File("src/bills/Invoice_no"+String.valueOf(t_id)+".png"));
    }

    billing(){
        quantity.setValue(1);
        java.sql.Date date =set_date_n_invoiceNO();
        ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>(11);
        table.setModel(new DefaultTableModel(
                null,new String[]{"Name","Quantity","Unit Price","Discount","GST","Total"}));
        add_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int Value = Integer.parseInt(item_id.getText());
                } catch (NumberFormatException err) {
                    JOptionPane.showMessageDialog(null, "Item_id should be numeric");
                    return;
                }
                if (item_id.getText().equals("") || quantity.getValue().equals("")||discount.getText().equals("") || gst.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Empty input fields");
                    return;
                }

                try {

                    Connection con = initialise_db.getConnection();
                    assert con != null;
                    PreparedStatement s1 = con.prepareStatement("USE SAS");
                    s1.executeUpdate();
                    create_sales_record_table(con);
                    PreparedStatement q = con.prepareStatement("SELECT * from item " +
                            "where item_id = "+item_id.getText());
                    System.out.println("passed");
                    System.out.println(q);
                    ResultSet result = q.executeQuery();
                    System.out.println("Passed");
                    if (!result.next()) {
                        JOptionPane.showMessageDialog(null, "Item not available");
                    }
                    else{
                        double quant =result.getDouble("quantity");
                        double jsquant    = Double.parseDouble(quantity.getValue().toString());
                        if(quant<jsquant){
                            JOptionPane.showMessageDialog(null, "Input Quantity exceedes available Quantity");
                            return;
                        }else if(jsquant<=0) {
                            JOptionPane.showMessageDialog(null, "Invalid input Quantity");
                            return;
                        }
                        ArrayList<String> arrtemp=new ArrayList<String>();
                        arrtemp.add(result.getString(1));
                        arrtemp.add(String.valueOf(jsquant));
                        arrtemp.add(result.getString(4));
                        arrtemp.add(result.getString(6));
                        arrtemp.add(result.getString(5));

                        double total_cost = Double.parseDouble(arrtemp.get(1))* Double.parseDouble(arrtemp.get(2));
                        total_cost+= -(total_cost*Double.parseDouble(arrtemp.get(3))/100)+(total_cost*Double.parseDouble(arrtemp.get(4))/100);
                        arrtemp.add(String.format("%.2f", total_cost));
                        System.out.println(arrtemp);
                        data.add(arrtemp);


                        System.out.println("DATE"+date.toString());

//                        CREATE TABLE IF NOT EXISTS sales_record (date DATETIME,t_id INTEGER,item_id INTEGER,Quantity INTEGER,UnitPrice DOUBLE,Discount DOUBLE,GST DOUBLE ,PROFIT DOUBLE)
                        PreparedStatement q1 = con.prepareStatement("INSERT INTO sales_record VALUES ("+"'"+date+"'"+","+t_id+","+item_id.getText()+","+arrtemp.get(1)+","+arrtemp.get(2)+","+arrtemp.get(3)+","+arrtemp.get(4)+","+arrtemp.get(5)+")");
                        q1.executeUpdate();

                        PreparedStatement update = con.prepareStatement("SET SQL_SAFE_UPDATES = 0");
                        update.executeUpdate();

                        PreparedStatement update2 = con.prepareStatement("update item set quantity =quantity -"+quant+" where item_id ="+item_id.getText());
                        update2.executeUpdate();


                        String[][] strarr = new String[items_per_bill][6];
                        int gross_cost=0;
                        for(int i=0;i< data.size();i++){
                            for(int j=0;j<6;j++){
                                if(i>=items_per_bill){
                                    JOptionPane.showMessageDialog(null, "Items limit per bill exceeded");
                                    return;
                                }
                                if(j==5)
                                    gross_cost+=Double.parseDouble(data.get(i).get(j));
                                strarr[i][j]=data.get(i).get(j);
                            }
                        }
                        System.out.println(data.size());
                        table.setModel(new DefaultTableModel(
                                strarr,new String[]{"Name","Quantity","Unit Price","Discount","GST","Total"}));
                        net_ammo.setText("NET PAYABLE AMMOUNT IN INR:"+gross_cost);

                    }
                } catch (Exception excp) {
                    System.out.println("here2");
                    JOptionPane.showMessageDialog(null, excp.getMessage());
                }
            }
        });
        DONEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login.jf.dispose();
            }
        });
        downloadBillButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    makeScreenshot(login.jf);
                    login.jf.dispose();
                    ImageInFrame("src/bills/Invoice_no"+String.valueOf(t_id)+".png");

                } catch (AWTException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

            }
        });
    }
}
